package com.borderlessos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BorderlessosBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(BorderlessosBackendApplication.class, args);
	}

}
